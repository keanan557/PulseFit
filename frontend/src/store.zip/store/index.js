import {createStore} from 'vuex'

export default createStore({
    state:{
        products:[]
    },
    mutations:{
        set_products(state, products){
            state.products = products
        }
    },
    actions:{
        async fetchProducts({commit}){
            try {
                const response = await fetch('http://localhost:3000/api/products');
                const data = await response.json();
                commit('set_products', data);
              } catch (error) {
                console.error('Error fetching products:', error);
              }
        }
    },
    getters: {
        allProducts: (state) => state.products
      }
})